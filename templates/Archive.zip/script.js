const c = new URLSearchParams(window.location.search).get('creator')
const v = new URLSearchParams(window.location.search).get('viewer')
console.log('minted by', c, 'viewer', v)
